//=============================================================================
//
//  Copyright (c) 2015, 2020 Qualcomm Technologies, Inc.
//  All Rights Reserved.
//  Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//=============================================================================

#pragma once

#ifndef ZDL_EXPORT
#define ZDL_EXPORT
#endif
